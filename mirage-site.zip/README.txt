npm install
npm run dev
http://localhost:3000